<?php
	$hostname = 'sql211.infinityfree.com';
	$username = 'if0_36617174';
	$password = '0ZZ8GzXvqai5TS';
	$dbdname  = 'if0_36617174_bukatoko';

	$conn = mysqli_connect($hostname, $username, $password, $dbdname) or die ('Gagal terhubung ke database');
?> 